package com.example.p17_4var

import android.content.Context
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RelativeLayout
class MainActivity : AppCompatActivity() {
    private var count = 0
    private lateinit var backgroundLayout: RelativeLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        backgroundLayout = findViewById(R.id.background)
        val preferences = getPreferences(Context.MODE_PRIVATE)
        count = preferences.getInt("count", 0)
        if (count == 0) {
            backgroundLayout.setBackgroundColor(Color.RED)
            backgroundLayout.setBackgroundColor(Color.GREEN)
        } else {
            backgroundLayout.setBackgroundColor(Color.BLUE)
        }
        count++
        val editor = preferences.edit()
        editor.putInt("", count)
        editor.apply()

    }
}