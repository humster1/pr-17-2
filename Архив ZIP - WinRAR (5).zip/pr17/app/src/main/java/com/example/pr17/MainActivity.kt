package com.example.pr17
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var pinCodeEditText: EditText
    private lateinit var loginButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pinCodeEditText = findViewById(R.id.pinCodeEditText)
        loginButton = findViewById(R.id.loginButton)

        loginButton.setOnClickListener {
            val pinCode = pinCodeEditText.text.toString()
        }
    }
}