
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pr17.R

class PinCodeActivity : AppCompatActivity() {

    private val correctPinCode = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onBackPressed() {

    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    fun checkPinCode(pinCode: String) {
        if (pinCode == correctPinCode) {

            Toast.makeText(this, "Пин-код верный", Toast.LENGTH_SHORT).show()

        } else {

            Toast.makeText(this, "Неверный пин-код", Toast.LENGTH_SHORT).show()
        }
    }
}
